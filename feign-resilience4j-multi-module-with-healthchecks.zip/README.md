# External API Clients with Healthchecks

This project demonstrates Feign, Resilience4j, and Spring Boot Actuator with healthchecks.